package com.example.bill_splitter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class Receipt extends AppCompatActivity {
    private TextView names;
    private TextView owed;

    private ArrayList<String> people;
    private ArrayList<Double> amountOwed;

    private final static String TAG = "BillSplitter";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
        Log.d(TAG, "New activity started");

        names = (TextView) findViewById(R.id.names);
        owed = (TextView) findViewById(R.id.owed);

        Intent intent = getIntent();
        Log.d(TAG, "Getting extras");
        people = intent.getExtras().getStringArrayList("NAMES");
        amountOwed = (ArrayList<Double>) intent.getExtras().getSerializable("OWED");

        for(int i = 0; i < people.size(); i++){
            String amountDisplay = String.format("%.2f",amountOwed.get(i).doubleValue());
            names.setText(names.getText()+people.get(i)+"\n");
            owed.setText(""+owed.getText()+amountDisplay+"\n");
        }

    }


}
